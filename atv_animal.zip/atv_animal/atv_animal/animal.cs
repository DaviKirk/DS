﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data;
using MySql.Data.MySqlClient;
using System.Data;
namespace atv_animal
{
    class animal : conexao
    {
        private string nome;
        private string genero;
        private string habitat;
        private string alimento;
        private string codigo;
        private string cor;

        public void setNome(string nome)
        {
            this.nome = nome;
        }
        public string getNome()
        {
            return this.nome;
        }
        public void setGenero(string genero)
        {
            this.genero = genero;
        }
        public string getGenero()
        {
            return this.genero;
        }
        public void setHabitat(string habitat)
        {
            this.habitat = habitat;
        }
        public string getHabitat()
        {
            return this.habitat;
        }
        public void setAlimento(string alimento)
        {
            this.alimento = alimento;
        }
        public string getAlimento()
        {
            return this.alimento;
        }
        public void setCor(string cor)
        {
            this.cor = cor;
        }
        public string getCor()
        {
            return this.cor;
        }
        public void setCodigo(string codigo)
        {
            this.codigo = codigo;
        }
        public string getCodigo()
        {
            return this.codigo;
        }
        public void inserir()
        {
            string query = "insert into animal(nome, genero, habitat, alimento, cor) values('" + getNome() + "','" + getGenero() + "', '" + getHabitat() + "', '" + getAlimento() + "', '" + getCor() + "')";
            //Abrir conexão, enviar ao banco de dados e fechar conexão
            if (this.AbrirConexao() == true)
            {
                MySqlCommand cmd = new MySqlCommand(query, conectar);
                cmd.ExecuteNonQuery();
                this.FecharConexao();
            }
        }
        //Método para analisar os dados
        public DataTable Consultar()
        {
            this.AbrirConexao();
            string mSQL = "Select * from animal";
            MySqlCommand cmd = new MySqlCommand(mSQL, conectar);
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);

            this.FecharConexao();
            DataTable dt = new DataTable();
            da.Fill(dt);
            return dt;
        }
        public void excluir()
        {
            string query = "delete from animal where codigo= '" + getCodigo() + "'";
            if (this.AbrirConexao() == true)
            {
                MySqlCommand cmd = new MySqlCommand(query, conectar);
                cmd.ExecuteNonQuery();
                this.FecharConexao();
            }
        }
    }
}
