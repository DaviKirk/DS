﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace atv_animal
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        animal a = new animal();
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                a.setNome(txt_nome.Text);
                a.setCor(txt_cor.Text);
                a.setGenero(txt_genero.Text);
                a.setHabitat(txt_habitat.Text);
                a.setAlimento(txt_alimento.Text);
                a.inserir();
            }
            finally
            {
                MessageBox.Show("Informações gravadas com sucesso");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = a.Consultar();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                a.setCodigo(txt_codigo.Text);
                a.excluir();
                dataGridView1.DataSource = a.Consultar();
            }
            finally
            {
                MessageBox.Show("Informações excluídas com sucesso");
            }
        }
    }
}
