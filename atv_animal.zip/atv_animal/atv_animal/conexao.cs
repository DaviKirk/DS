﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data;
using MySql.Data.MySqlClient;
using System.Data;
namespace atv_animal
{
    class conexao
    {
        // Criação das variáveis
        public MySqlConnection conectar;
        public string servidor;
        public string database;
        public string usuario;
        public string senha;

        // Construtor
        public conexao()
        {
            Inicializar();
        }

        public void Inicializar()
        {
            servidor = "127.0.0.1";
            database = "atv_animal";
            usuario = "root";
            senha = "";
            string conexaoString = $"SERVER={servidor};DATABASE={database};UID={usuario};PASSWORD={senha};";
            conectar = new MySqlConnection(conexaoString);
        }

        public bool AbrirConexao()
        {
            try
            {
                conectar.Open();
                return true;
            }
            catch (MySqlException ex)
            {
                switch (ex.Number)
                {
                    case 0:
                        Console.WriteLine("Não foi possível conectar ao servidor.");
                        break;
                    case 1045:
                        Console.WriteLine("Usuário ou senha inválidos.");
                        break;
                    default:
                        Console.WriteLine($"Erro de conexão: {ex.Message}");
                        break;
                }
                return false;
            }
        }

        public bool FecharConexao()
        {
            try
            {
                if (conectar != null && conectar.State == System.Data.ConnectionState.Open)
                {
                    conectar.Close();
                    return true;
                }
                return false;
            }
            catch (MySqlException ex)
            {
                Console.WriteLine($"Erro ao fechar a conexão: {ex.Message}");
                return false;
            }
        }
    }
}
